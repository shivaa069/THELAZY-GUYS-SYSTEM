/**
 * Professional Document Scanner Engine
 * Pipeline: Detect → Adjust → Transform → Enhance → Export
 * 
 * Features:
 * - Edge detection with contour finding
 * - 4-corner perspective transform (homography)
 * - Smart image enhancement (adaptive threshold, contrast, sharpening)
 * - Multiple enhancement modes (Color, Grayscale, B&W)
 * - Brightness/Contrast controls
 * - Multi-page PDF generation
 */

import { jsPDF } from 'jspdf';

// ─── TYPES ──────────────────────────────────────────────────────────────────────

export interface Point {
  x: number;
  y: number;
}

export interface CropCorners {
  topLeft: Point;
  topRight: Point;
  bottomRight: Point;
  bottomLeft: Point;
}

export type EnhancementMode = 'color' | 'grayscale' | 'bw';

export interface ScanSettings {
  brightness: number;    // -100 to 100
  contrast: number;      // -100 to 100
  rotation: number;      // 0, 90, 180, 270
  mode: EnhancementMode;
  sharpen: boolean;
}

export interface ScanPage {
  id: string;
  file: File;
  originalUrl: string;
  processedUrl?: string;
  corners?: CropCorners;
  settings: ScanSettings;
  naturalWidth: number;
  naturalHeight: number;
}

export const DEFAULT_SETTINGS: ScanSettings = {
  brightness: 0,
  contrast: 10,
  rotation: 0,
  mode: 'color',
  sharpen: true,
};

// ─── IMAGE LOADING ──────────────────────────────────────────────────────────────

export function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

export function loadImageFromFile(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = URL.createObjectURL(file);
  });
}

// ─── EDGE DETECTION ─────────────────────────────────────────────────────────────

/**
 * Detect document edges using a simplified Canny-like approach.
 * Returns 4 corner points of the detected document rectangle.
 */
export async function detectDocumentEdges(
  file: File
): Promise<CropCorners | null> {
  const img = await loadImageFromFile(file);
  
  // Work on a smaller version for speed
  const maxDim = 600;
  const scale = Math.min(maxDim / img.width, maxDim / img.height, 1);
  const w = Math.round(img.width * scale);
  const h = Math.round(img.height * scale);
  
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  ctx.drawImage(img, 0, 0, w, h);
  
  const imageData = ctx.getImageData(0, 0, w, h);
  const gray = toGrayscaleArray(imageData);
  
  // Apply Gaussian blur
  const blurred = gaussianBlur(gray, w, h, 2);
  
  // Sobel edge detection
  const edges = sobelEdges(blurred, w, h);
  
  // Threshold edges
  const threshold = otsuThreshold(edges);
  const binary = edges.map(v => v > threshold * 0.5 ? 255 : 0);
  
  // Find contours and largest rectangle
  const corners = findLargestRectangle(binary, w, h);
  
  if (corners) {
    // Scale corners back to original image dimensions
    const invScale = 1 / scale;
    return {
      topLeft: { x: corners.topLeft.x * invScale, y: corners.topLeft.y * invScale },
      topRight: { x: corners.topRight.x * invScale, y: corners.topRight.y * invScale },
      bottomRight: { x: corners.bottomRight.x * invScale, y: corners.bottomRight.y * invScale },
      bottomLeft: { x: corners.bottomLeft.x * invScale, y: corners.bottomLeft.y * invScale },
    };
  }
  
  // Fallback: return image bounds with small margin
  const margin = 0.03;
  return {
    topLeft: { x: img.width * margin, y: img.height * margin },
    topRight: { x: img.width * (1 - margin), y: img.height * margin },
    bottomRight: { x: img.width * (1 - margin), y: img.height * (1 - margin) },
    bottomLeft: { x: img.width * margin, y: img.height * (1 - margin) },
  };
}

function toGrayscaleArray(imageData: ImageData): number[] {
  const d = imageData.data;
  const gray: number[] = new Array(imageData.width * imageData.height);
  for (let i = 0; i < gray.length; i++) {
    const j = i * 4;
    gray[i] = 0.299 * d[j] + 0.587 * d[j + 1] + 0.114 * d[j + 2];
  }
  return gray;
}

function gaussianBlur(data: number[], w: number, h: number, radius: number): number[] {
  const kernel = createGaussianKernel(radius);
  const kSize = kernel.length;
  const half = Math.floor(kSize / 2);
  const result = new Array(data.length).fill(0);
  
  // Horizontal pass
  const temp = new Array(data.length).fill(0);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let sum = 0;
      let wSum = 0;
      for (let k = -half; k <= half; k++) {
        const nx = Math.min(w - 1, Math.max(0, x + k));
        const weight = kernel[k + half];
        sum += data[y * w + nx] * weight;
        wSum += weight;
      }
      temp[y * w + x] = sum / wSum;
    }
  }
  
  // Vertical pass
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let sum = 0;
      let wSum = 0;
      for (let k = -half; k <= half; k++) {
        const ny = Math.min(h - 1, Math.max(0, y + k));
        const weight = kernel[k + half];
        sum += temp[ny * w + x] * weight;
        wSum += weight;
      }
      result[y * w + x] = sum / wSum;
    }
  }
  
  return result;
}

function createGaussianKernel(radius: number): number[] {
  const size = radius * 2 + 1;
  const kernel: number[] = new Array(size);
  const sigma = radius / 3;
  for (let i = 0; i < size; i++) {
    const x = i - radius;
    kernel[i] = Math.exp(-(x * x) / (2 * sigma * sigma));
  }
  return kernel;
}

function sobelEdges(data: number[], w: number, h: number): number[] {
  const edges = new Array(data.length).fill(0);
  for (let y = 1; y < h - 1; y++) {
    for (let x = 1; x < w - 1; x++) {
      const gx =
        -data[(y - 1) * w + (x - 1)] + data[(y - 1) * w + (x + 1)]
        - 2 * data[y * w + (x - 1)] + 2 * data[y * w + (x + 1)]
        - data[(y + 1) * w + (x - 1)] + data[(y + 1) * w + (x + 1)];
      const gy =
        -data[(y - 1) * w + (x - 1)] - 2 * data[(y - 1) * w + x] - data[(y - 1) * w + (x + 1)]
        + data[(y + 1) * w + (x - 1)] + 2 * data[(y + 1) * w + x] + data[(y + 1) * w + (x + 1)];
      edges[y * w + x] = Math.sqrt(gx * gx + gy * gy);
    }
  }
  return edges;
}

function otsuThreshold(data: number[]): number {
  const histogram = new Array(256).fill(0);
  for (const v of data) {
    histogram[Math.min(255, Math.max(0, Math.round(v)))]++;
  }
  const total = data.length;
  let sumAll = 0;
  for (let i = 0; i < 256; i++) sumAll += i * histogram[i];
  
  let sumB = 0, wB = 0, maxVariance = 0, threshold = 0;
  for (let t = 0; t < 256; t++) {
    wB += histogram[t];
    if (wB === 0) continue;
    const wF = total - wB;
    if (wF === 0) break;
    sumB += t * histogram[t];
    const mB = sumB / wB;
    const mF = (sumAll - sumB) / wF;
    const variance = wB * wF * (mB - mF) * (mB - mF);
    if (variance > maxVariance) {
      maxVariance = variance;
      threshold = t;
    }
  }
  return threshold;
}

function findLargestRectangle(binary: number[], w: number, h: number): CropCorners | null {
  // Simple approach: scan for connected edge pixels and find bounding quadrilateral
  // using Hough-like line detection simplified
  
  // Collect edge points
  const edgePoints: Point[] = [];
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      if (binary[y * w + x] > 128) {
        edgePoints.push({ x, y });
      }
    }
  }
  
  if (edgePoints.length < 20) return null;
  
  // Find convex hull of edge points (simplified Graham scan)
  const hull = convexHull(edgePoints);
  if (hull.length < 4) return null;
  
  // Find 4 corners of the hull that form the best rectangle
  return findFourCorners(hull, w, h);
}

function convexHull(points: Point[]): Point[] {
  if (points.length < 3) return points;
  
  // Sample points for performance (max 2000)
  let sampled = points;
  if (points.length > 2000) {
    const step = Math.floor(points.length / 2000);
    sampled = points.filter((_, i) => i % step === 0);
  }
  
  sampled.sort((a, b) => a.x === b.x ? a.y - b.y : a.x - b.x);
  
  const cross = (O: Point, A: Point, B: Point) =>
    (A.x - O.x) * (B.y - O.y) - (A.y - O.y) * (B.x - O.x);
  
  const lower: Point[] = [];
  for (const p of sampled) {
    while (lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], p) <= 0)
      lower.pop();
    lower.push(p);
  }
  
  const upper: Point[] = [];
  for (let i = sampled.length - 1; i >= 0; i--) {
    const p = sampled[i];
    while (upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], p) <= 0)
      upper.pop();
    upper.push(p);
  }
  
  lower.pop();
  upper.pop();
  return lower.concat(upper);
}

function findFourCorners(hull: Point[], w: number, h: number): CropCorners {
  // Find the point closest to each image corner
  const imageCorners = [
    { x: 0, y: 0 },       // topLeft
    { x: w, y: 0 },       // topRight
    { x: w, y: h },       // bottomRight
    { x: 0, y: h },       // bottomLeft
  ];
  
  const findClosest = (target: Point) => {
    let minDist = Infinity;
    let closest = hull[0];
    for (const p of hull) {
      const dist = Math.hypot(p.x - target.x, p.y - target.y);
      if (dist < minDist) { minDist = dist; closest = p; }
    }
    return closest;
  };
  
  return {
    topLeft: findClosest(imageCorners[0]),
    topRight: findClosest(imageCorners[1]),
    bottomRight: findClosest(imageCorners[2]),
    bottomLeft: findClosest(imageCorners[3]),
  };
}

// ─── PERSPECTIVE TRANSFORM ──────────────────────────────────────────────────────

/**
 * Apply perspective transform using bilinear interpolation.
 * Maps the 4 source corners to a flat rectangle.
 */
export async function applyPerspectiveTransform(
  imageSrc: string,
  corners: CropCorners,
  outputWidth?: number,
  outputHeight?: number
): Promise<string> {
  const img = await loadImage(imageSrc);
  
  const src = [corners.topLeft, corners.topRight, corners.bottomRight, corners.bottomLeft];
  
  // Calculate output dimensions from the document shape
  const widthTop = Math.hypot(src[1].x - src[0].x, src[1].y - src[0].y);
  const widthBottom = Math.hypot(src[2].x - src[3].x, src[2].y - src[3].y);
  const heightLeft = Math.hypot(src[3].x - src[0].x, src[3].y - src[0].y);
  const heightRight = Math.hypot(src[2].x - src[1].x, src[2].y - src[1].y);
  
  const outW = outputWidth || Math.round(Math.max(widthTop, widthBottom));
  const outH = outputHeight || Math.round(Math.max(heightLeft, heightRight));
  
  // Source canvas
  const srcCanvas = document.createElement('canvas');
  srcCanvas.width = img.width;
  srcCanvas.height = img.height;
  const srcCtx = srcCanvas.getContext('2d')!;
  srcCtx.drawImage(img, 0, 0);
  const srcData = srcCtx.getImageData(0, 0, img.width, img.height);
  
  // Destination canvas
  const dstCanvas = document.createElement('canvas');
  dstCanvas.width = outW;
  dstCanvas.height = outH;
  const dstCtx = dstCanvas.getContext('2d')!;
  const dstData = dstCtx.createImageData(outW, outH);
  
  // Compute perspective transform matrix
  const matrix = computePerspectiveMatrix(
    src,
    [
      { x: 0, y: 0 },
      { x: outW, y: 0 },
      { x: outW, y: outH },
      { x: 0, y: outH },
    ]
  );
  
  if (matrix) {
    // Use the inverse matrix to map dst → src
    for (let dy = 0; dy < outH; dy++) {
      for (let dx = 0; dx < outW; dx++) {
        // Map destination point back to source
        const denom = matrix[6] * dx + matrix[7] * dy + 1;
        const sx = (matrix[0] * dx + matrix[1] * dy + matrix[2]) / denom;
        const sy = (matrix[3] * dx + matrix[4] * dy + matrix[5]) / denom;
        
        // Bilinear interpolation
        const x0 = Math.floor(sx);
        const y0 = Math.floor(sy);
        const x1 = x0 + 1;
        const y1 = y0 + 1;
        
        if (x0 < 0 || y0 < 0 || x1 >= img.width || y1 >= img.height) continue;
        
        const fx = sx - x0;
        const fy = sy - y0;
        
        const dIdx = (dy * outW + dx) * 4;
        for (let c = 0; c < 4; c++) {
          const v00 = srcData.data[(y0 * img.width + x0) * 4 + c];
          const v10 = srcData.data[(y0 * img.width + x1) * 4 + c];
          const v01 = srcData.data[(y1 * img.width + x0) * 4 + c];
          const v11 = srcData.data[(y1 * img.width + x1) * 4 + c];
          
          dstData.data[dIdx + c] = Math.round(
            v00 * (1 - fx) * (1 - fy) +
            v10 * fx * (1 - fy) +
            v01 * (1 - fx) * fy +
            v11 * fx * fy
          );
        }
      }
    }
  }
  
  dstCtx.putImageData(dstData, 0, 0);
  return dstCanvas.toDataURL('image/jpeg', 0.95);
}

/**
 * Compute perspective transformation matrix.
 * Maps src[0..3] → dst[0..3].
 * Returns the inverse matrix coefficients for dst→src mapping.
 */
function computePerspectiveMatrix(
  src: Point[],
  dst: Point[]
): number[] | null {
  // Solve the 8x8 system for perspective transform
  // dst_x = (a*src_x + b*src_y + c) / (g*src_x + h*src_y + 1)
  // dst_y = (d*src_x + e*src_y + f) / (g*src_x + h*src_y + 1)
  // 
  // We need the inverse: given dst coords, find src coords
  // So we solve: src = f(dst) 
  
  const A = [
    [dst[0].x, dst[0].y, 1, 0, 0, 0, -src[0].x * dst[0].x, -src[0].x * dst[0].y],
    [0, 0, 0, dst[0].x, dst[0].y, 1, -src[0].y * dst[0].x, -src[0].y * dst[0].y],
    [dst[1].x, dst[1].y, 1, 0, 0, 0, -src[1].x * dst[1].x, -src[1].x * dst[1].y],
    [0, 0, 0, dst[1].x, dst[1].y, 1, -src[1].y * dst[1].x, -src[1].y * dst[1].y],
    [dst[2].x, dst[2].y, 1, 0, 0, 0, -src[2].x * dst[2].x, -src[2].x * dst[2].y],
    [0, 0, 0, dst[2].x, dst[2].y, 1, -src[2].y * dst[2].x, -src[2].y * dst[2].y],
    [dst[3].x, dst[3].y, 1, 0, 0, 0, -src[3].x * dst[3].x, -src[3].x * dst[3].y],
    [0, 0, 0, dst[3].x, dst[3].y, 1, -src[3].y * dst[3].x, -src[3].y * dst[3].y],
  ];
  
  const b = [src[0].x, src[0].y, src[1].x, src[1].y, src[2].x, src[2].y, src[3].x, src[3].y];
  
  return solveLinearSystem(A, b);
}

function solveLinearSystem(A: number[][], b: number[]): number[] | null {
  const n = b.length;
  // Augmented matrix
  const M = A.map((row, i) => [...row, b[i]]);
  
  // Gaussian elimination with partial pivoting
  for (let col = 0; col < n; col++) {
    let maxRow = col;
    let maxVal = Math.abs(M[col][col]);
    for (let row = col + 1; row < n; row++) {
      if (Math.abs(M[row][col]) > maxVal) {
        maxVal = Math.abs(M[row][col]);
        maxRow = row;
      }
    }
    if (maxVal < 1e-10) return null;
    [M[col], M[maxRow]] = [M[maxRow], M[col]];
    
    for (let row = col + 1; row < n; row++) {
      const factor = M[row][col] / M[col][col];
      for (let j = col; j <= n; j++) {
        M[row][j] -= factor * M[col][j];
      }
    }
  }
  
  // Back substitution
  const x = new Array(n).fill(0);
  for (let i = n - 1; i >= 0; i--) {
    x[i] = M[i][n];
    for (let j = i + 1; j < n; j++) {
      x[i] -= M[i][j] * x[j];
    }
    x[i] /= M[i][i];
  }
  
  return x;
}

// ─── IMAGE ENHANCEMENT ──────────────────────────────────────────────────────────

/**
 * Apply the full enhancement pipeline to an image.
 */
export async function enhanceImage(
  imageSrc: string,
  settings: ScanSettings
): Promise<string> {
  const img = await loadImage(imageSrc);
  
  const canvas = document.createElement('canvas');
  let w = img.width;
  let h = img.height;
  
  // Handle rotation
  const isRotated90 = settings.rotation === 90 || settings.rotation === 270;
  if (isRotated90) {
    canvas.width = h;
    canvas.height = w;
  } else {
    canvas.width = w;
    canvas.height = h;
  }
  
  const ctx = canvas.getContext('2d')!;
  
  // Apply rotation
  if (settings.rotation > 0) {
    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.rotate((settings.rotation * Math.PI) / 180);
    ctx.drawImage(img, -w / 2, -h / 2);
    ctx.restore();
  } else {
    ctx.drawImage(img, 0, 0);
  }
  
  w = canvas.width;
  h = canvas.height;
  
  const imageData = ctx.getImageData(0, 0, w, h);
  const d = imageData.data;
  
  // Apply enhancement mode
  if (settings.mode === 'grayscale') {
    for (let i = 0; i < d.length; i += 4) {
      const gray = 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
      d[i] = d[i + 1] = d[i + 2] = gray;
    }
  } else if (settings.mode === 'bw') {
    // Adaptive threshold for B&W document mode
    const gray = new Float32Array(w * h);
    for (let i = 0; i < gray.length; i++) {
      gray[i] = 0.299 * d[i * 4] + 0.587 * d[i * 4 + 1] + 0.114 * d[i * 4 + 2];
    }
    
    // Block-based adaptive threshold
    const blockSize = Math.max(15, Math.round(Math.min(w, h) / 30) | 1);
    const C = 8; // threshold constant
    
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const half = Math.floor(blockSize / 2);
        let sum = 0, count = 0;
        for (let dy = -half; dy <= half; dy++) {
          for (let dx = -half; dx <= half; dx++) {
            const ny = Math.min(h - 1, Math.max(0, y + dy));
            const nx = Math.min(w - 1, Math.max(0, x + dx));
            sum += gray[ny * w + nx];
            count++;
          }
        }
        const mean = sum / count;
        const idx = (y * w + x) * 4;
        const val = gray[y * w + x] > mean - C ? 255 : 0;
        d[idx] = d[idx + 1] = d[idx + 2] = val;
      }
    }
  }
  
  // Apply brightness and contrast
  const brightnessOffset = settings.brightness * 2.55;
  const contrastFactor = (259 * (settings.contrast + 255)) / (255 * (259 - settings.contrast));
  
  for (let i = 0; i < d.length; i += 4) {
    for (let c = 0; c < 3; c++) {
      let val = d[i + c];
      // Contrast
      val = contrastFactor * (val - 128) + 128;
      // Brightness
      val += brightnessOffset;
      d[i + c] = Math.max(0, Math.min(255, val));
    }
  }
  
  // Apply sharpening (unsharp mask)
  if (settings.sharpen && settings.mode !== 'bw') {
    const copy = new Uint8ClampedArray(d);
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const idx = (y * w + x) * 4;
        for (let c = 0; c < 3; c++) {
          const center = copy[idx + c];
          const neighbors = (
            copy[((y - 1) * w + x) * 4 + c] +
            copy[((y + 1) * w + x) * 4 + c] +
            copy[(y * w + (x - 1)) * 4 + c] +
            copy[(y * w + (x + 1)) * 4 + c]
          ) / 4;
          d[idx + c] = Math.max(0, Math.min(255, center + (center - neighbors) * 0.4));
        }
      }
    }
  }
  
  ctx.putImageData(imageData, 0, 0);
  return canvas.toDataURL('image/jpeg', 0.95);
}

// ─── FULL PROCESSING PIPELINE ───────────────────────────────────────────────────

/**
 * Process a single page through the full scanner pipeline:
 * Perspective Transform → Enhancement
 */
export async function processPage(page: ScanPage): Promise<string> {
  let imageSrc = page.originalUrl;
  
  // Step 1: Apply perspective transform if corners are set
  if (page.corners) {
    imageSrc = await applyPerspectiveTransform(imageSrc, page.corners);
  }
  
  // Step 2: Apply enhancement
  const result = await enhanceImage(imageSrc, page.settings);
  return result;
}

// ─── PDF GENERATION ─────────────────────────────────────────────────────────────

/**
 * Generate a high-quality PDF from processed page images.
 */
export async function generateScannedPDF(processedUrls: string[]): Promise<void> {
  if (processedUrls.length === 0) throw new Error('No images to process');

  const firstImg = await loadImage(processedUrls[0]);
  const isPortrait = firstImg.height >= firstImg.width;
  
  const pdf = new jsPDF({
    orientation: isPortrait ? 'portrait' : 'landscape',
    unit: 'mm',
    format: 'a4',
  });

  for (let i = 0; i < processedUrls.length; i++) {
    if (i > 0) pdf.addPage();

    const img = await loadImage(processedUrls[i]);
    const pageW = pdf.internal.pageSize.getWidth();
    const pageH = pdf.internal.pageSize.getHeight();
    
    const imgAspect = img.width / img.height;
    const pageAspect = pageW / pageH;
    
    let drawW: number, drawH: number, drawX: number, drawY: number;
    
    if (imgAspect > pageAspect) {
      drawW = pageW;
      drawH = pageW / imgAspect;
      drawX = 0;
      drawY = (pageH - drawH) / 2;
    } else {
      drawH = pageH;
      drawW = pageH * imgAspect;
      drawX = (pageW - drawW) / 2;
      drawY = 0;
    }
    
    pdf.addImage(processedUrls[i], 'JPEG', drawX, drawY, drawW, drawH);
  }

  pdf.save('scanned_document.pdf');
}

// ─── CORNER DRAWING HELPER ──────────────────────────────────────────────────────

/**
 * Draw the detected/adjusted corners on a canvas overlay.
 */
export function drawCornersOverlay(
  ctx: CanvasRenderingContext2D,
  corners: CropCorners,
  canvasWidth: number,
  canvasHeight: number,
  imgWidth: number,
  imgHeight: number
): void {
  const scaleX = canvasWidth / imgWidth;
  const scaleY = canvasHeight / imgHeight;
  
  const pts = [
    { x: corners.topLeft.x * scaleX, y: corners.topLeft.y * scaleY },
    { x: corners.topRight.x * scaleX, y: corners.topRight.y * scaleY },
    { x: corners.bottomRight.x * scaleX, y: corners.bottomRight.y * scaleY },
    { x: corners.bottomLeft.x * scaleX, y: corners.bottomLeft.y * scaleY },
  ];
  
  ctx.clearRect(0, 0, canvasWidth, canvasHeight);
  
  // Semi-transparent overlay outside crop
  ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
  ctx.fillRect(0, 0, canvasWidth, canvasHeight);
  
  // Clear the crop area
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(pts[0].x, pts[0].y);
  ctx.lineTo(pts[1].x, pts[1].y);
  ctx.lineTo(pts[2].x, pts[2].y);
  ctx.lineTo(pts[3].x, pts[3].y);
  ctx.closePath();
  ctx.globalCompositeOperation = 'destination-out';
  ctx.fill();
  ctx.restore();
  
  // Draw border
  ctx.strokeStyle = 'hsl(28, 85%, 55%)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(pts[0].x, pts[0].y);
  ctx.lineTo(pts[1].x, pts[1].y);
  ctx.lineTo(pts[2].x, pts[2].y);
  ctx.lineTo(pts[3].x, pts[3].y);
  ctx.closePath();
  ctx.stroke();
  
  // Draw corner handles
  const handleRadius = 10;
  for (const pt of pts) {
    ctx.beginPath();
    ctx.arc(pt.x, pt.y, handleRadius, 0, Math.PI * 2);
    ctx.fillStyle = 'hsl(28, 85%, 55%)';
    ctx.fill();
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 2;
    ctx.stroke();
  }
}
