import * as pdfjsLib from 'pdfjs-dist';

pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.4.168/pdf.worker.min.mjs`;

export interface FeasibilityData {
  name: string;
  mobile: string;
  email: string;
  applicationNumber: string;
}

export async function extractFeasibilityData(file: File): Promise<FeasibilityData> {
  const arrayBuffer = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
  const page = await pdf.getPage(1);
  const textContent = await page.getTextContent();
  const fullText = (textContent.items as any[])
    .map((item) => item.str)
    .join(' ');

  const nameMatch = fullText.match(/Name\s+of\s+Applicant\s+([\s\S]*?)(?=\s*(?:Mobile|3\s))/i);
  let name = nameMatch ? nameMatch[1].trim().replace(/\s+/g, ' ') : '';

  const mobileMatch = fullText.match(/Mobile\s+No\.?\s*(\d[\d\s-]*\d)/i);
  const mobile = mobileMatch ? mobileMatch[1].replace(/\s/g, '').trim() : '';

  const emailMatch = fullText.match(/Email\s+ID\s+([\w.+-]+@[\w.-]+\.\w+)/i);
  const email = emailMatch ? emailMatch[1].trim() : '';

  let applicationNumber = '';
  const appMatch = fullText.match(/(?:Application\s+Reference\s+Number)[\/\s]*(?:Date)?\s*(NP-[A-Z0-9-]+)/i);
  if (appMatch) {
    applicationNumber = appMatch[1].trim();
  } else {
    const appMatch2 = fullText.match(/(NP-[A-Z]{5}\d{2}-\d+)/);
    applicationNumber = appMatch2 ? appMatch2[1] : '';
  }

  if (!name) {
    const nameMatch2 = fullText.match(/Sh\/Smt\s+([A-Z\s]+?)(?=\s*Date)/i);
    name = nameMatch2 ? nameMatch2[1].trim() : '';
  }

  return { name, mobile, email, applicationNumber };
}
